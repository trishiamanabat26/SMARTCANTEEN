<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ffeb3b;
            text-align: center;
            margin: 0;
            padding: 0;
        }
        .container {
            background: white;
            padding: 20px;
            margin: 50px auto;
            width: 50%;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #fbc02d;
        }
        .logout-btn {
            background: #f57c00;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin-top: 20px;
        }
        .logout-btn:hover {
            background: #e65100;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Welcome to the Smart Canteen Dashboard</h2>
        <p>Hello, <strong><?php echo $_SESSION['username']; ?></strong></p>
        <p>Your Station: <strong><?php echo $_SESSION['station']; ?></strong></p>
        <a class="logout-btn" href="logout.php">Logout</a>
    </div>
</body>
</html>