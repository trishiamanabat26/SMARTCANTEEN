<?php
// update_password.php - Updates the user's password
session_start();
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
    $email = $_SESSION['reset_email'];
    
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
    $stmt->bind_param("ss", $new_password, $email);
    if ($stmt->execute()) {
        echo "Password updated successfully. <a href='login.html'>Login</a>";
    } else {
        echo "Error updating password.";
    }
}
?>
