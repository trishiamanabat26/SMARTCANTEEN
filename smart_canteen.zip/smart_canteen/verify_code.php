<?php
// verify_code.php - Verifies the code entered by the user
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $entered_code = $_POST['code'];
    if ($entered_code == $_SESSION['reset_code']) {
        header("Location: new_password.html");
    } else {
        echo "Invalid code. Please try again.";
    }
}
?>