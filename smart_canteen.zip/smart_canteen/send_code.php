<?php
// send_code.php - Sends a verification code via email
session_start();
require 'db_connect.php'; // Database connection
require 'mailer.php'; // PHPMailer setup

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']); // Trim whitespace

    // Check if database connection is working
    if (!$conn) {
        die("Database Connection Failed: " . mysqli_connect_error());
    }

    // Prepare SQL statement
    $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
    
    if (!$stmt) {
        die("Database Error: " . $conn->error); // Debugging statement
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if email exists
    if ($result->num_rows > 0) {
        $code = rand(100000, 999999);
        $_SESSION['reset_email'] = $email;
        $_SESSION['reset_code'] = $code;

        // Send email
        if (send_verification_email($email, $code)) {
            header("Location: verify_code.html");
            exit(); // Ensure script stops after redirect
        } else {
            die("Error: Failed to send email. Please try again.");
        }
    } else {
        die("Error: Email not found in our records.");
    }

    $stmt->close();
    $conn->close();
}
?>
