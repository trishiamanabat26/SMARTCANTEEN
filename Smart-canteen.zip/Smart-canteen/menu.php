<?php
session_start();
require_once 'firestore.php';

// Redirect if not logged in
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$db = getFirestore();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_category'])) {
        $db->collection('categories')->add([
            'name' => $_POST['category_name'],
            'createdAt' => new DateTime(),
            'station' => $_SESSION['station'] // Add station to category
        ]);
        header("Location: menu.php?success=Category added");
        exit();
    }
    
    if (isset($_POST['add_item'])) {
        $db->collection('menu_items')->add([
            'name' => $_POST['item_name'],
            'price' => (float)$_POST['item_price'],
            'category' => $_POST['item_category'],
            'station' => $_SESSION['station'], // Use logged-in user's station
            'createdAt' => new DateTime()
        ]);
        header("Location: menu.php?success=Item added");
        exit();
    }
}

// Get data filtered by station
$categories = $db->collection('categories')
                ->where('station', '==', $_SESSION['station'])
                ->documents();
$menuItems = $db->collection('menu_items')
               ->where('station', '==', $_SESSION['station'])
               ->documents();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Smart Canteen - Menu Management</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-app-compat.js"></script>
  <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-auth-compat.js"></script>
  <script src="auth.js"></script>
</head>
<body>

  <div class="container">
    <!-- Image -->
    <div class="image-container">
      <img src="food.png" alt="Smart Canteen">
      <div class="user-info">
        <span><?= htmlspecialchars($_SESSION['username']) ?></span>
        <span>Station: <?= htmlspecialchars($_SESSION['station']) ?></span>
        <button onclick="logoutUser()" class="btn-logout">Logout</button>
      </div>
    </div>

    <!-- Form Section -->
    <div class="form-container">
      <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_GET['success']) ?></div>
      <?php endif; ?>

      <!-- Add Category Form -->
      <div class="form-section">
        <h2>Add New Category</h2>
        <form method="POST">
          <div class="input-container">
            <i class="fa-solid fa-tag icon"></i>
            <input type="text" name="category_name" placeholder="Category Name" required>
          </div>
          <button type="submit" name="add_category" class="btn">Add Category</button>
        </form>
      </div>

      <!-- Add Menu Item Form -->
      <div class="form-section">
        <h2>Add Menu Item</h2>
        <form method="POST">
          <div class="input-container">
            <i class="fa-solid fa-utensils icon"></i>
            <input type="text" name="item_name" placeholder="Item Name" required>
          </div>
          
          <div class="input-container">
            <i class="fa-solid fa-tag icon"></i>
            <select name="item_category" required>
              <option value="">Select Category</option>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= htmlspecialchars($cat['name']) ?>">
                  <?= htmlspecialchars($cat['name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          
          <div class="input-container">
            <i class="fa-solid fa-money-bill-wave icon"></i>
            <input type="number" step="0.01" name="item_price" placeholder="Price" required>
          </div>
          
          <button type="submit" name="add_item" class="btn">Add Item</button>
        </form>
      </div>

      <!-- Menu Items Table -->
      <div class="menu-table">
        <h2>Current Menu (Station <?= htmlspecialchars($_SESSION['station']) ?>)</h2>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Category</th>
              <th>Price</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($menuItems as $item): ?>
              <tr>
                <td><?= htmlspecialchars($item['name']) ?></td>
                <td><?= htmlspecialchars($item['category']) ?></td>
                <td>₱<?= number_format($item['price'], 2) ?></td>
                <td>
                  <button class="btn-edit" onclick="editItem('<?= $item->id() ?>')">
                    <i class="fa-solid fa-pen"></i>
                  </button>
                  <button class="btn-delete" onclick="deleteItem('<?= $item->id() ?>')">
                    <i class="fa-solid fa-trash"></i>
                  </button>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Edit Modal -->
  <div id="editModal" class="modal hidden">
    <div class="modal-content">
      <span class="close" onclick="closeModal()">&times;</span>
      <h2>Edit Menu Item</h2>
      <form id="editForm">
        <input type="hidden" id="editItemId">
        <div class="input-container">
          <i class="fa-solid fa-utensils icon"></i>
          <input type="text" id="editItemName" placeholder="Item Name" required>
        </div>
        <div class="input-container">
          <i class="fa-solid fa-tag icon"></i>
          <select id="editItemCategory" required>
            <option value="">Select Category</option>
            <?php foreach ($categories as $cat): ?>
              <option value="<?= htmlspecialchars($cat['name']) ?>">
                <?= htmlspecialchars($cat['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="input-container">
          <i class="fa-solid fa-money-bill-wave icon"></i>
          <input type="number" step="0.01" id="editItemPrice" placeholder="Price" required>
        </div>
        <button type="button" class="btn" onclick="updateItem()">Update Item</button>
      </form>
    </div>
  </div>

  <script>
    // Authentication functions
    function showLogin() {
      document.getElementById("loginForm").classList.remove("hidden");
      document.getElementById("signupForm").classList.add("hidden");
      document.getElementById("resetForm").classList.add("hidden");
    }
    
    function showSignup() {
      document.getElementById("signupForm").classList.remove("hidden");
      document.getElementById("loginForm").classList.add("hidden");
      document.getElementById("resetForm").classList.add("hidden");
    }
    
    function showReset() {
      document.getElementById("resetForm").classList.remove("hidden");
      document.getElementById("loginForm").classList.add("hidden");
      document.getElementById("signupForm").classList.add("hidden");
    }
    
    function logoutUser() {
      firebase.auth().signOut().then(() => {
        window.location.href = 'logout.php';
      }).catch((error) => {
        alert(error.message);
      });
    }

    // Menu item functions
    function editItem(itemId) {
      // Fetch item data and populate modal
      fetch('get_item.php?id=' + itemId)
        .then(response => response.json())
        .then(data => {
          document.getElementById('editItemId').value = itemId;
          document.getElementById('editItemName').value = data.name;
          document.getElementById('editItemPrice').value = data.price;
          document.getElementById('editItemCategory').value = data.category;
          document.getElementById('editModal').classList.remove('hidden');
        });
    }

    function updateItem() {
      const itemId = document.getElementById('editItemId').value;
      const itemData = {
        name: document.getElementById('editItemName').value,
        price: parseFloat(document.getElementById('editItemPrice').value),
        category: document.getElementById('editItemCategory').value
      };

      fetch('update_item.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: itemId, ...itemData })
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          location.reload();
        } else {
          alert('Error updating item');
        }
      });
    }

    function deleteItem(itemId) {
      if (confirm('Are you sure you want to delete this item?')) {
        fetch('delete_item.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: itemId })
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            location.reload();
          } else {
            alert('Error deleting item');
          }
        });
      }
    }

    function closeModal() {
      document.getElementById('editModal').classList.add('hidden');
    }
  </script>
</body>
</html>