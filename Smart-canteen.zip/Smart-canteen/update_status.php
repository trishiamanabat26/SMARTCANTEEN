<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Check if required POST data is received
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['status'])) {
    $orderId = trim($_POST['order_id']);
    $status = trim($_POST['status']);

    // Basic validation
    $validStatuses = ['Pending', 'In Progress', 'Completed', 'Cancelled'];
    if (!in_array($status, $validStatuses)) {
        die("❌ Invalid status.");
    }

    // ---- File-based data handling example ----
    // Assuming orders are saved in a file called orders.json
    $ordersFile = 'orders.json';
    if (!file_exists($ordersFile)) {
        die("❌ Orders file not found.");
    }

    $ordersData = json_decode(file_get_contents($ordersFile), true);
    $orderFound = false;

    // Update order status
    foreach ($ordersData as &$order) {
        if ($order['order_id'] === $orderId) {
            $order['status'] = $status;
            $orderFound = true;
            break;
        }
    }

    if ($orderFound) {
        file_put_contents($ordersFile, json_encode($ordersData, JSON_PRETTY_PRINT));
        header("Location: home.php?updated=1");
        exit();
    } else {
        die("❌ Order ID not found.");
    }

} else {
    die("❌ Invalid request.");
}
?>
