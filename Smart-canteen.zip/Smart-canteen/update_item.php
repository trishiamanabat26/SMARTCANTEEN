<?php
require_once 'firestore.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$db = getFirestore();

try {
    $db->collection('menu_items')
       ->document($data['id'])
       ->set([
           'name' => $data['name'],
           'price' => (float)$data['price'],
           'category' => $data['category'],
           'updatedAt' => new DateTime()
       ], ['merge' => true]);
    
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>