<?php
require_once 'firestore.php';
header('Content-Type: application/json');

// Check if ID parameter exists
if (!isset($_GET['id'])) {
    http_response_code(400); // Bad Request
    echo json_encode(['error' => 'Item ID not provided']);
    exit();
}

$itemId = $_GET['id'];
$db = getFirestore();

try {
    // Get the document reference
    $itemRef = $db->collection('menu_items')->document($itemId);
    
    // Get the document snapshot
    $snapshot = $itemRef->snapshot();
    
    if ($snapshot->exists()) {
        $itemData = $snapshot->data();
        // Add the document ID to the response
        $itemData['id'] = $snapshot->id();
        echo json_encode($itemData);
    } else {
        http_response_code(response_code: 404); // Not Found
        echo json_encode(['error' => 'Item not found']);
    }
} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'error' => 'Database error',
        'message' => $e->getMessage()
    ]);
}
?>