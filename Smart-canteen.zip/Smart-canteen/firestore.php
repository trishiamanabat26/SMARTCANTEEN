<?php
require __DIR__ . '\vendor\autoload.php';

use Google\Cloud\Firestore\FirestoreClient;

function getFirestore() {
    $keyPath = __DIR__ . '\firebase-credentials.json';
    
    if (!file_exists($keyPath)) {
        die('Error: Firebase credentials not found at ' . $keyPath);
    }

    return new FirestoreClient([
        'projectId' => 'smartcanteen-d9071',
        'keyFilePath' => $keyPath,
        'transport' => 'rest' // Force REST API
    ]);
}