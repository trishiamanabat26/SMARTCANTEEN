function showLogin() {
    document.getElementById("loginForm").classList.remove("hidden");
    document.getElementById("signupForm").classList.add("hidden");
    document.getElementById("resetForm").classList.add("hidden");
  }
  
  function showSignup() {
    document.getElementById("signupForm").classList.remove("hidden");
    document.getElementById("loginForm").classList.add("hidden");
    document.getElementById("resetForm").classList.add("hidden");
  }
  
  function showReset() {
    document.getElementById("resetForm").classList.remove("hidden");
    document.getElementById("loginForm").classList.add("hidden");
    document.getElementById("signupForm").classList.add("hidden");
  }
  
  function registerUser() {
    const station = document.getElementById("signupStation").value;
    const name = document.getElementById("signupName").value;
    const contact = document.getElementById("signupContact").value;
    const email = document.getElementById("signupEmail").value;
    const password = document.getElementById("signupPassword").value;
    const confirm = document.getElementById("signupConfirmPassword").value;
  
    if (password !== confirm) {
      alert("Passwords do not match");
      return;
    }
  
    auth.createUserWithEmailAndPassword(email, password)
      .then(cred => {
        return db.collection("users").doc(cred.user.uid).set({
          station: station,
          name: name,
          contact: contact,
          email: email
        });
      })
      .then(() => {
        alert("Account created!");
        showLogin();
      })
      .catch(error => {
        alert(error.message);
      });
  }
  function loginUser() {
    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;
  
    firebase.auth().signInWithEmailAndPassword(email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        const db = firebase.firestore();
  
        db.collection("users").doc(user.uid).get()
          .then(doc => {
            if (doc.exists) {
              const data = doc.data();
  
              // Send data to PHP to set session
              fetch('set_session.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  username: data.name,
                  station: data.station,
                  contact: data.contact
                })
              })
              .then(res => res.json())
              .then(response => {
                if (response.success) {
                  window.location.href = 'home.php'; // redirect on success
                } else {
                  alert('Session creation failed.');
                }
              });
  
            } else {
              alert("No such user in Firestore.");
            }
          });
      })
      .catch((error) => {
        alert(error.message);
      });
  }
  
  function sendResetEmail() {
    const email = document.getElementById("resetEmail").value;
  
    auth.sendPasswordResetEmail(email)
      .then(() => {
        alert("Reset email sent.");
        showLogin();
      })
      .catch(error => {
        alert(error.message);
      });
  }
  