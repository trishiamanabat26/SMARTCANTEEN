<?php
session_start();
require_once 'firestore.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!isset($input['id'], $input['name'])) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        exit();
    }

    try {
        $db = getFirestore();
        $catRef = $db->collection('categories')->document($input['id']);

        $category = $catRef->snapshot();
        if ($category->exists() && $category['station'] === $_SESSION['station']) {
            $catRef->update([
                ['path' => 'name', 'value' => $input['name']]
            ]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Unauthorized or not found']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}
