<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Smart Canteen - Login & Signup</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-app-compat.js"></script>
  <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-auth-compat.js"></script>
  <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore-compat.js"></script>
  <script src="firebase-config.js"></script>
</head>
<body>

  <div class="container">
    <!-- Image -->
    <div class="image-container">
      <img src="food.png" alt="Smart Canteen">
    </div>

    <!-- Form Section -->
    <div class="form-container">
      <!-- Login Form -->
      <div id="loginForm">
        <h2>Staff Login</h2>

        <div class="input-container">
          <i class="fa-solid fa-circle-user icon"></i>
          <input type="email" id="loginEmail" placeholder="Email" required>
        </div>

        <div class="input-container">
          <i class="fa-solid fa-lock icon"></i>
          <input type="password" id="loginPassword" placeholder="Password" required>
        </div>

        <a href="#" class="forgot-password" onclick="showReset()">Forgot Password?</a>

        <button class="btn" onclick="loginUser()">Login</button>

        <div class="signup-link">
          Don't have an account? <a href="#" onclick="showSignup()">Sign Up</a>
        </div>
      </div>

      <!-- Signup Form -->
      <div id="signupForm" class="hidden">
        <h2>Register Account</h2>

        <select id="signupStation">
          <option value="">Select Station</option>
          <option value="Station 1">Station 1</option>
          <option value="Station 2">Station 2</option>
          <option value="Station 3">Station 3</option>
          <option value="Station 3">Station 4</option>
          <option value="Station 3">Station 5</option>
        </select>

        <div class="input-container">
          <i class="fa-solid fa-user icon"></i>
          <input type="text" id="signupName" placeholder="Full Name" required>
        </div>

        <div class="input-container">
          <i class="fa-solid fa-phone icon"></i>
          <input type="text" id="signupContact" placeholder="Contact Number" required>
        </div>

        <div class="input-container">
          <i class="fa-solid fa-circle-user icon"></i>
          <input type="email" id="signupEmail" placeholder="Email" required>
        </div>

        <div class="input-container">
          <i class="fa-solid fa-lock icon"></i>
          <input type="password" id="signupPassword" placeholder="Password" required>
        </div>

        <div class="input-container">
          <i class="fa-solid fa-lock icon"></i>
          <input type="password" id="signupConfirmPassword" placeholder="Confirm Password" required>
        </div>

        <button class="btn" onclick="registerUser()">Sign Up</button>

        <div class="signup-link">
          Already have an account? <a href="#" onclick="showLogin()">Sign In</a>
        </div>
      </div>

      <!-- Reset Form -->
      <div id="resetForm" class="hidden">
        <h2>Reset Password</h2>
        <div class="input-container">
          <i class="fa-solid fa-envelope icon"></i>
          <input type="email" id="resetEmail" placeholder="Enter your email">
        </div>
        <button class="btn" onclick="sendResetEmail()">Send Reset Email</button>
        <div class="signup-link">
          <a href="#" onclick="showLogin()">Back to Login</a>
        </div>
      </div>
    </div>
  </div>

  <script src="auth.js"></script>
</body>
</html>
