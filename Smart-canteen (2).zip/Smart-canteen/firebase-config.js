const firebaseConfig = {
    apiKey: "AIzaSyBO7SMnbKbpac9gnunSTX0Rs445W7wkXvc",
    authDomain: "smartcanteen-d9071.firebaseapp.com",
    databaseURL: "https://smartcanteen-d9071-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "smartcanteen-d9071",
    storageBucket: "smartcanteen-d9071.firebasestorage.app",
    messagingSenderId: "296929255961",
    appId: "1:296929255961:web:07d7ac03df687829e98088",
    measurementId: "G-7F8M4YEEQ2"
  };
  
  firebase.initializeApp(firebaseConfig);
  const auth = firebase.auth();
  const db = firebase.firestore();
  