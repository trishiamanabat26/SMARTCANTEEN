<?php
require_once 'db.php';
$pdo = getPDO();

if (!isset($_GET['id'])) {
    echo "No item selected.";
    exit;
}

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM menu_items WHERE id = ?");
$stmt->execute([$id]);
$item = $stmt->fetch();

if (!$item) {
    echo "Item not found.";
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Preview Item</title>
    <link rel="stylesheet" href="menu.css">
</head>
<body>
<div class="preview-container">
    <h2><?= htmlspecialchars($item['name']) ?></h2>
    <?php if ($item['image']): ?>
        <img src="<?= htmlspecialchars($item['image']) ?>" class="preview-image">
    <?php endif; ?>
    <p><strong>Category:</strong> <?= htmlspecialchars($item['category']) ?></p>
    <p><strong>Price:</strong> ₱<?= number_format($item['price'], 2) ?></p>
    <a href="menu.php" class="btn btn-back">← Back to Menu</a>
</div>
</body>
</html>
