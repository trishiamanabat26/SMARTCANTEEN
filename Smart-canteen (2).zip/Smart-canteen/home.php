<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$ordersFile = 'orders.json';
$orders = file_exists($ordersFile) ? json_decode(file_get_contents($ordersFile), true) : [];

$summary = [
    'Pending' => 0,
    'In Progress' => 0,
    'Completed' => 0,
    'Cancelled' => 0,
];

foreach ($orders as $order) {
    $status = $order['status'];
    if (isset($summary[$status])) {
        $summary[$status]++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Canteen Go</title>
    <link rel="stylesheet" href="home.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
</head>
<body>
<div class="container">
    <aside class="sidebar">
        <div class="logo">
            <img src="food.png" alt="Logo">
            <h2>Canteen Go</h2>
        </div>
        <ul>
            <li class="active"><a href="home.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="orders.php"><i class="fas fa-list"></i> Orders</a></li>
            <li><a href="menu.php"><i class="fas fa-utensils"></i> Menu</a></li>
            <li><a href="inventory.php"><i class="fas fa-chart-line"></i> Inventory</a></li>
            <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <div class="icons">
                <i class="fas fa-bell" id="notifBtn"></i>
                <i class="fas fa-user-circle" id="profileBtn"></i>
            </div>
        </header>

        <?php if (isset($_GET['updated'])): ?>
            <div class="alert success">✅ Order status updated successfully!</div>
        <?php endif; ?>

        <div class="popup" id="notifPopup">
            <div class="popup-header"><i class="fas fa-bell"></i> Notifications</div>
            <p><strong>Admin approved</strong> to add Fruitshakes Siomai on the menu.<br><small>5 minutes ago</small></p>
        </div>

        <div class="popup" id="profilePopup">
            <div class="popup-header"><i class="fas fa-user"></i> <?php echo strtoupper(htmlspecialchars($_SESSION['station'])); ?></div>
            <p><strong>Username:</strong> <?php echo htmlspecialchars($_SESSION['username']); ?></p>
            <p><strong>Station:</strong> <?php echo htmlspecialchars($_SESSION['station']); ?></p>
            <p><strong>Contact:</strong> <?php echo htmlspecialchars($_SESSION['contact']); ?></p>
        </div>

        <div class="popup" id="selectPopup">
            <form method="POST" action="update_status.php" id="statusForm">
                <div class="popup-header"><i class="fas fa-tasks"></i> Update Order Status</div>
                <input type="hidden" name="order_id" id="selectedOrderId">
                <button name="status" value="In Progress">In Progress</button>
                <button name="status" value="Completed">Completed</button>
                <button name="status" value="Cancelled">Cancelled</button>
            </form>
        </div>

        <section class="dashboard-section">
            <div class="summary-cards">
                <div class="card" onclick="filterByStatus('Pending')">Pending <span><?= $summary['Pending'] ?></span></div>
                <div class="card" onclick="filterByStatus('In Progress')">In Progress <span><?= $summary['In Progress'] ?></span></div>
                <div class="card" onclick="filterByStatus('Completed')">Completed <span><?= $summary['Completed'] ?></span></div>
                <div class="card" onclick="filterByStatus('Cancelled')">Cancelled <span><?= $summary['Cancelled'] ?></span></div>
            </div>

            <div class="sales-inventory">
                <h3>Sales Inventory</h3>
                <table>
                    <thead>
                        <tr><th>Order ID</th><th>Items</th><th>Products</th><th>Price</th><th>Date</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?= htmlspecialchars($order['id']) ?></td>
                            <td><?= htmlspecialchars($order['items']) ?></td>
                            <td><?= htmlspecialchars($order['products']) ?></td>
                            <td>₱<?= htmlspecialchars($order['total']) ?></td>
                            <td><?= htmlspecialchars($order['date']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="order-list">
                <h3>Order List</h3>
                <div class="filter-controls">
                    <input type="text" id="orderSearch" placeholder="Search order ID or product...">
                    <select id="statusFilter">
                        <option value="">All Status</option>
                        <option value="Pending">Pending</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                    <button onclick="clearFilters()">Clear</button>
                </div>
                <table id="orderTable">
                    <thead>
                        <tr><th>Order ID</th><th>Items</th><th>Products</th><th>Total</th><th>Date</th><th>Status</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?= htmlspecialchars($order['id']) ?></td>
                            <td><?= htmlspecialchars($order['items']) ?></td>
                            <td><?= htmlspecialchars($order['products']) ?></td>
                            <td>₱<?= htmlspecialchars($order['total']) ?></td>
                            <td><?= htmlspecialchars($order['date']) ?></td>
                            <td><span class="status <?= strtolower(str_replace(' ', '-', $order['status'])) ?>"><?= htmlspecialchars($order['status']) ?></span></td>
                            <td><button class="selectBtn" data-order-id="<?= htmlspecialchars($order['id']) ?>">Select</button></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="best-sellers">
                <h3>Best Sellers</h3>
                <ul>
                    <li>🍱 Siomai ala Carte</li>
                    <li>🍟 Fries</li>
                    <li>🥙 Shawarma</li>
                </ul>
            </div>
        </section>
    </main>
</div>

<script>
const notifBtn = document.getElementById('notifBtn');
const profileBtn = document.getElementById('profileBtn');
const selectBtns = document.querySelectorAll('.selectBtn');
const notifPopup = document.getElementById('notifPopup');
const profilePopup = document.getElementById('profilePopup');
const selectPopup = document.getElementById('selectPopup');

notifBtn.onclick = () => togglePopup(notifPopup);
profileBtn.onclick = () => togglePopup(profilePopup);

selectBtns.forEach(btn => {
    btn.onclick = () => {
        document.getElementById('selectedOrderId').value = btn.dataset.orderId;
        togglePopup(selectPopup);
    };
});

function togglePopup(popup) {
    [notifPopup, profilePopup, selectPopup].forEach(p => {
        if (p !== popup) p.classList.remove('active');
    });
    popup.classList.toggle('active');
}

document.addEventListener('click', function(event) {
    if (!event.target.closest('.popup') &&
        !event.target.closest('.selectBtn') &&
        !event.target.closest('#notifBtn') &&
        !event.target.closest('#profileBtn')) {
        [notifPopup, profilePopup, selectPopup].forEach(p => p.classList.remove('active'));
    }
});

document.getElementById("orderSearch").addEventListener("keyup", filterTable);
document.getElementById("statusFilter").addEventListener("change", filterTable);

function filterTable() {
    const searchValue = document.getElementById("orderSearch").value.toLowerCase();
    const statusValue = document.getElementById("statusFilter").value;
    const rows = document.querySelectorAll("#orderTable tbody tr");

    rows.forEach(row => {
        const text = row.innerText.toLowerCase();
        const status = row.querySelector(".status").innerText.trim();

        const matchesSearch = text.includes(searchValue);
        const matchesStatus = !statusValue || status === statusValue;

        row.style.display = matchesSearch && matchesStatus ? "" : "none";
    });
}

function filterByStatus(status) {
    document.getElementById("statusFilter").value = status;
    filterTable();
    document.querySelectorAll(".summary-cards .card").forEach(card => {
        card.classList.remove("active");
        if (card.innerText.includes(status)) card.classList.add("active");
    });
    document.getElementById("orderTable").scrollIntoView({ behavior: 'smooth' });
}

function clearFilters() {
    document.getElementById("orderSearch").value = "";
    document.getElementById("statusFilter").value = "";
    document.querySelectorAll(".summary-cards .card").forEach(card => card.classList.remove("active"));
    filterTable();
}
</script>
</body>
</html>
