<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$pdo = getPDO();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_category'])) {
        $stmt = $pdo->prepare("INSERT INTO categories (name, station) VALUES (?, ?)");
        $stmt->execute([$_POST['category_name'], $_SESSION['station']]);
        header("Location: menu.php?success=Category added");
        exit();
    }

    if (isset($_POST['add_item'])) {
        $name = $_POST['item_name'];
        $price = $_POST['item_price'];
        $category = $_POST['item_category'];
        $station = $_SESSION['station'];

        $imagePath = '';
        if (!empty($_FILES['item_image']['name'])) {
            $targetDir = "uploads/";
            $fileName = basename($_FILES["item_image"]["name"]);
            $targetFile = $targetDir . time() . "_" . $fileName;

            $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png'];

            if (in_array($imageFileType, $allowed)) {
                if (move_uploaded_file($_FILES["item_image"]["tmp_name"], $targetFile)) {
                    $imagePath = $targetFile;
                }
            }
        }

        $stmt = $pdo->prepare("INSERT INTO menu_items (name, price, category, station, image) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $price, $category, $station, $imagePath]);

        header("Location: menu.php?success=Item added");
        exit();
    }
}

$stmt = $pdo->prepare("SELECT * FROM categories WHERE station = ?");
$stmt->execute([$_SESSION['station']]);
$categories = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM menu_items WHERE station = ?");
$stmt->execute([$_SESSION['station']]);
$menuItems = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Canteen Go - Menu</title>
    <link rel="stylesheet" href="menu.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
</head>
<body>
<div class="container">
    <aside class="sidebar">
        <div class="logo">
            <img src="food.png" alt="Logo">
            <h2>Canteen Go</h2>
        </div>
        <ul>
            <li><a href="home.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="orders.php"><i class="fas fa-list"></i> Orders</a></li>
            <li class="active"><a href="menu.php"><i class="fas fa-utensils"></i> Menu</a></li>
            <li><a href="inventory.php"><i class="fas fa-chart-line"></i> Inventory</a></li>
            <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <div class="icons">
                <i class="fas fa-bell" id="notifBtn"></i>
                <i class="fas fa-user-circle" id="profileBtn"></i>
            </div>
        </header>

        <?php if (isset($_GET['success'])): ?>
            <div class="alert success">✅ <?= htmlspecialchars($_GET['success']) ?></div>
        <?php endif; ?>

        <div class="popup" id="profilePopup">
            <div class="popup-header"><i class="fas fa-user"></i> <?= strtoupper(htmlspecialchars($_SESSION['station'])) ?></div>
            <p><strong>Username:</strong> <?= htmlspecialchars($_SESSION['username']) ?></p>
            <p><strong>Station:</strong> <?= htmlspecialchars($_SESSION['station']) ?></p>
            <p><strong>Contact:</strong> <?= htmlspecialchars($_SESSION['contact']) ?></p>
        </div>

        <section class="dashboard-section">
            <h2>Menu Management</h2>

            <div class="summary-cards">
                <div class="card"><?= count($categories) ?> Categories</div>
                <div class="card"><?= count($menuItems) ?> Items</div>
            </div>

            <div class="form-section">
                <h3>Add Category</h3>
                <form method="POST">
                    <input type="text" name="category_name" placeholder="Category Name" required>
                    <button type="submit" name="add_category">Add Category</button>
                </form>
            </div>

            <div class="form-section">
                <h3>Add Menu Item</h3>
                <form method="POST" enctype="multipart/form-data">
                    <input type="text" name="item_name" placeholder="Item Name" required>
                    <select name="item_category" required>
                        <option value="">Select Category</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= htmlspecialchars($cat['name']) ?>"><?= htmlspecialchars($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="number" step="0.01" name="item_price" placeholder="Price" required>
                    <input type="file" name="item_image" accept=".jpg,.jpeg,.png">
                    <button type="submit" name="add_item">Add Item</button>
                </form>
            </div>

            <div class="table-section">
                <h3>Current Menu</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($menuItems as $item): ?>
                        <tr>
                            <td>
                                <?php if ($item['image']): ?>
                                    <img src="<?= htmlspecialchars($item['image']) ?>" alt="Food" class="thumb">
                                <?php else: ?>
                                    <span>No Image</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($item['name']) ?></td>
                            <td><?= htmlspecialchars($item['category']) ?></td>
                            <td>₱<?= number_format($item['price'], 2) ?></td>
                            <td>
                                <a href="preview.php?id=<?= $item['id'] ?>" class="btn btn-preview">Preview</a>
                                <a href="edit_item.php?id=<?= $item['id'] ?>" class="btn btn-edit">Edit</a>
                                <a href="delete_item.php?id=<?= $item['id'] ?>" class="btn btn-delete" onclick="return confirm('Are you sure?')">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>

<script>
const profileBtn = document.getElementById('profileBtn');
const profilePopup = document.getElementById('profilePopup');

profileBtn.onclick = () => {
    profilePopup.classList.toggle('active');
};

document.addEventListener('click', function(event) {
    if (!event.target.closest('.popup') && !event.target.closest('#profileBtn')) {
        profilePopup.classList.remove('active');
    }
});
</script>
</body>
</html>
