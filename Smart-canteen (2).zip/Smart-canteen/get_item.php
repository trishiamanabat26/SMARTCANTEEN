<?php
require_once 'db.php';

if (!isset($_GET['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'ID is required']);
    exit();
}

$pdo = getPDO();
$stmt = $pdo->prepare("SELECT * FROM menu_items WHERE id = ?");
$stmt->execute([$_GET['id']]);
$item = $stmt->fetch();

if ($item) {
    echo json_encode($item);
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Item not found']);
}
?>
