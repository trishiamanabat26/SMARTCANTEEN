<?php
require 'firestore.php';

try {
    $db = getFirestore();
    echo "Firestore connection successful!";
    
    // Test a simple operation
    $docRef = $db->collection('test')->document('test');
    $docRef->set(['test' => 'value']);
    echo "Test document created successfully!";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}