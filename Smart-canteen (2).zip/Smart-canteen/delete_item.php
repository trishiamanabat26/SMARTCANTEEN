<?php
require_once 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'ID is required']);
    exit();
}

$pdo = getPDO();
$stmt = $pdo->prepare("DELETE FROM menu_items WHERE id = ?");
$success = $stmt->execute([$data['id']]);

echo json_encode(['success' => $success]);
?>
