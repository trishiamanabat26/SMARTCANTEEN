<?php
require_once 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['id'], $data['name'], $data['price'], $data['category'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit();
}

$pdo = getPDO();
$stmt = $pdo->prepare("UPDATE menu_items SET name = ?, price = ?, category = ? WHERE id = ?");
$success = $stmt->execute([
    $data['name'],
    $data['price'],
    $data['category'],
    $data['id']
]);

echo json_encode(['success' => $success]);
?>
