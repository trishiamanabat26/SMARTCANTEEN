<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sales Inventory - Canteen Go</title>
    <link rel="stylesheet" href="dashboard.css">
    <link rel="stylesheet" href="inventory.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="logo">
                <img src="food.png" alt="Logo">
                <h2>Canteen Go</h2>
            </div>
            <ul>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'home.php' ? 'active' : ''; ?>">
                    <a href="home.php"><i class="fas fa-home"></i> Home</a>
                </li>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'orders.php' ? 'active' : ''; ?>">
                    <a href="orders.php"><i class="fas fa-list"></i> Orders</a>
                </li>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'menu.php' ? 'active' : ''; ?>">
                    <a href="menu.php"><i class="fas fa-utensils"></i> Menu</a>
                </li>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'inventory.php' ? 'active' : ''; ?>">
                    <a href="inventory.php"><i class="fas fa-chart-line"></i> Sales Inventory</a>
                </li>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
                    <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
                </li>
                <li>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="topbar">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search sales...">
                </div>
                <div class="icons">
                    <i class="fas fa-bell" id="notifBtn"></i>
                    <i class="fas fa-user-circle" id="profileBtn"></i>
                </div>
            </header>

            <!-- Popups -->
             
            
<div class="popup" id="notifPopup">
    <div class="popup-header">
        <i class="fas fa-bell"></i> Notifications
        <span class="badge">3 new</span>
    </div>
    <div class="popup-content">
        <div class="notification-item unread">
            <div class="notification-title">New order received</div>
            <div class="notification-desc">Burger Meal with Fries</div>
            <div class="notification-time">2 minutes ago</div>
        </div>
        <div class="notification-item unread">
            <div class="notification-title">Low stock alert</div>
            <div class="notification-desc">Only 3 Siomai left in inventory</div>
            <div class="notification-time">15 minutes ago</div>
        </div>
        <div class="notification-item">
            <div class="notification-title">Order completed</div>
            <div class="notification-desc">Order #005 has been completed</div>
            <div class="notification-time">1 hour ago</div>
        </div>
        <div class="notification-actions">
            <button class="btn btn-link">Mark all as read</button>
            <button class="btn btn-link">View all notifications</button>
        </div>
    </div>
</div>

<div class="popup" id="profilePopup">
    <div class="popup-header">
        <i class="fas fa-user"></i> User Profile
    </div>
    <div class="popup-content">
        <div class="profile-info">
            <div class="profile-avatar">
                <i class="fas fa-user-circle"></i>
            </div>
            <div class="profile-details">
                <div class="profile-name"><?php echo $_SESSION['username']; ?></div>
                <div class="profile-role">Station 1</div>
            </div>
        </div>
        <div class="profile-stats">
            <div class="stat-item">
                <div class="stat-value">42</div>
                <div class="stat-label">Orders Today</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">₱2,150</div>
                <div class="stat-label">Sales Today</div>
            </div>
        </div>
        <div class="profile-actions">
            <button class="btn btn-block">
                <i class="fas fa-user-edit"></i> Edit Profile
            </button>
            <button class="btn btn-block">
                <i class="fas fa-cog"></i> Settings
            </button>
            <button class="btn btn-block btn-logout">
                <i class="fas fa-sign-out-alt"></i> Logout
            </button>
        </div>
    </div>
</div>

            <!-- Sales Inventory Content -->
            <section class="sales-inventory">
                <div class="section-header">
                    <h2>Sales Inventory</h2>
                    <div class="filter-controls">
                        <div class="filter-tabs">
                            <button class="filter-tab active">All</button>
                            <button class="filter-tab">Best Seller</button>
                        </div>
                        <button class="btn btn-primary">
                            <i class="fas fa-download"></i> Export
                        </button>
                    </div>
                </div>
                
                <div class="sales-table-container">
                    <table class="sales-table">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Items</th>
                                <th>Products</th>
                                <th>Price</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>001</td>
                                <td>1</td>
                                <td>Burger</td>
                                <td>₱50</td>
                                <td>11/12/2024</td>
                                <td>
                                    <button class="btn btn-icon btn-view"><i class="fas fa-eye"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>002</td>
                                <td>3</td>
                                <td>Siomai, Fries, Shawarma</td>
                                <td>₱150</td>
                                <td>11/15/2024</td>
                                <td>
                                    <button class="btn btn-icon btn-view"><i class="fas fa-eye"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>003</td>
                                <td>2</td>
                                <td>Burger, Fries</td>
                                <td>₱100</td>
                                <td>11/16/2024</td>
                                <td>
                                    <button class="btn btn-icon btn-view"><i class="fas fa-eye"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>004</td>
                                <td>2</td>
                                <td>Fruitshakes, Siomai</td>
                                <td>₱100</td>
                                <td>11/17/2024</td>
                                <td>
                                    <button class="btn btn-icon btn-view"><i class="fas fa-eye"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>005</td>
                                <td>1</td>
                                <td>Fruitshakes</td>
                                <td>₱50</td>
                                <td>11/18/2024</td>
                                <td>
                                    <button class="btn btn-icon btn-view"><i class="fas fa-eye"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>006</td>
                                <td>2</td>
                                <td>Siomai, Burger</td>
                                <td>₱80</td>
                                <td>11/19/2024</td>
                                <td>
                                    <button class="btn btn-icon btn-view"><i class="fas fa-eye"></i></button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="table-footer">
                    <div class="pagination-controls">
                        <button class="btn btn-icon"><i class="fas fa-chevron-left"></i></button>
                        <span>Page 1 of 2</span>
                        <button class="btn btn-icon"><i class="fas fa-chevron-right"></i></button>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script src="inventory.js"></script>
</body>
</html>