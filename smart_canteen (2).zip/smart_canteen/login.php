<?php
session_start();
require 'config.php';

$error = '';

// If already logged in, redirect
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emailOrUsername = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($emailOrUsername) || empty($password)) {
        $error = "Please fill in both fields.";
    } else {
        // Check using email or username
        $stmt = $conn->prepare("SELECT id, password FROM users WHERE email = ? OR username = ?");
        $stmt->bind_param("ss", $emailOrUsername, $emailOrUsername);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Invalid email/username or password.";
            }
        } else {
            $error = "Account not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div class="container">
    <div class="image-container">
        <img src="food.png" alt="Login Illustration">
    </div>
    <div class="form-container">
        <h2>Login to Your Account</h2>

        <?php if (!empty($error)): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="success-message"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <form action="login.php" method="post">
            <div class="input-container">
                <i class="fas fa-user icon"></i>
                <input type="text" name="email" placeholder="Email or Username" required>
            </div>

            <div class="input-container">
                <i class="fas fa-lock icon"></i>
                <input type="password" name="password" id="password" placeholder="Password" required>
                <i class="toggle-password fas fa-eye" onclick="togglePassword()"></i>
            </div>

            <a href="reset-password.php" class="forgot-password">Forgot Password?</a>

            <button type="submit" class="btn">Login</button>

            <div class="signup-link">
                Don't have an account? <a href="signup.php">Sign up</a>
            </div>
        </form>
    </div>
</div>

<script>
    function togglePassword() {
        const password = document.getElementById('password');
        const icon = document.querySelector('.toggle-password');
        if (password.type === 'password') {
            password.type = 'text';
            icon.classList.replace('fa-eye', 'fa-eye-slash');
        } else {
            password.type = 'password';
            icon.classList.replace('fa-eye-slash', 'fa-eye');
        }
    }
</script>
</body>
</html>
