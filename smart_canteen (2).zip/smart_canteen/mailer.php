<?php
// mailer.php - Handles email sending
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load PHPMailer
require 'vendor/autoload.php';

function send_verification_email($email, $code) {
    $mail = new PHPMailer(true);
    
    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->SMTPDebug = 0; // Change to 2 for debugging
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'trishiamae.manabat@gmail.com';  // Replace with your Gmail
        $mail->Password = 'orgo cmfm wnup chii';    // Replace with your **App Password**
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Sender & Recipient
        $mail->setFrom('trishiamae.manabat@gmail.com', 'Smart Canteen Password Reset');
        $mail->addAddress($email);

        // Email Content
        $mail->isHTML(true);
        $mail->Subject = 'Your Password Reset Code';
        $mail->Body    = "<p>Your password reset code is: <b>$code</b></p><p>If you didn't request this, please ignore this email.</p>";

        // Send Email
        if ($mail->send()) {
            return true;  // Success
        } else {
            error_log("Email Error: " . $mail->ErrorInfo);
            return false; // Failed
        }
    } catch (Exception $e) {
        error_log("Mailer Exception: " . $e->getMessage()); // Log error
        return false;
    }
}
?>
