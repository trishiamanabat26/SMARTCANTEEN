<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Canteen Go</title>
    <link rel="stylesheet" href="dashboard.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
        .popup {
            display: none;
            position: absolute;
            background: white;
            border: 1px solid #ccc;
            padding: 15px;
            box-shadow: 0px 2px 8px rgba(0, 0, 0, 0.1);
            z-index: 100;
            border-radius: 10px;
            width: 250px;
        }
        .popup.active {
            display: block;
        }
        .popup-header {
            font-weight: bold;
            margin-bottom: 10px;
        }
        .popup i {
            margin-right: 5px;
        }
        .popup button {
            display: block;
            width: 100%;
            margin: 5px 0;
            padding: 10px;
            background-color: #5f5c00;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .popup button:hover {
            background-color: #4b4900;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <aside class="sidebar">
    <div class="logo">
        <img src="food.png" alt="Logo">
        <h2>Canteen Go</h2>
    </div>
    <ul>
        <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'home.php' ? 'active' : ''; ?>">
            <a href="home.php"><i class="fas fa-home"></i> Home</a>
        </li>
        <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'orders.php' ? 'active' : ''; ?>">
            <a href="orders.php"><i class="fas fa-list"></i> Orders</a>
        </li>
        <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'menu.php' ? 'active' : ''; ?>">
            <a href="menu.php"><i class="fas fa-utensils"></i> Menu</a>
        </li>
        <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'inventory.php' ? 'active' : ''; ?>">
            <a href="inventory.php"><i class="fas fa-chart-line"></i> Inventory</a>
        </li>
        <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
            <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
        </li>
        <li>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </li>
    </ul>
</aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="topbar">
                <input type="text" placeholder="Search orders...">
                <div class="icons">
                    <i class="fas fa-bell" id="notifBtn"></i>
                    <i class="fas fa-user-circle" id="profileBtn"></i>
                </div>
            </header>

            <!-- Popups -->
            <div class="popup" id="notifPopup">
                <div class="popup-header"><i class="fas fa-bell"></i> Notifications</div>
                <p><strong>Admin approved</strong> to add Fruitshakes Siomai on the menu.<br><small>5 minutes ago</small></p>
            </div>

            <div class="popup" id="profilePopup">
                <div class="popup-header"><i class="fas fa-user"></i> STATION 1</div>
                <p>Username: <?php echo $_SESSION['username']; ?></p>
            </div>

            <div class="popup" id="selectPopup">
                <div class="popup-header"><i class="fas fa-tasks"></i> Update Order Status</div>
                <button>In Progress</button>
                <button>Completed</button>
                <button>Cancelled</button>
            </div>

            <!-- Dashboard Panels -->
            <section class="dashboard-section">
                <div class="summary-cards">
                    <div class="card">Current <span>3</span></div>
                    <div class="card">Pending <span>3</span></div>
                    <div class="card">In Progress <span>0</span></div>
                    <div class="card">Completed <span>0</span></div>
                    <div class="card">Cancelled <span>0</span></div>
                </div>

                <!-- Sales Inventory -->
                <div class="sales-inventory">
                    <h3>Sales Inventory</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Items</th>
                                <th>Products</th>
                                <th>Price</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>001</td>
                                <td>1</td>
                                <td>Burger</td>
                                <td>₱50</td>
                                <td>11/12/2024</td>
                            </tr>
                            <tr>
                                <td>002</td>
                                <td>3</td>
                                <td>Siomai, Fries, Shawarma</td>
                                <td>₱150</td>
                                <td>11/15/2024</td>
                            </tr>
                            <tr>
                                <td>003</td>
                                <td>2</td>
                                <td>Siomai, Fries</td>
                                <td>₱100</td>
                                <td>11/16/2024</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Orders Table -->
                <div class="order-list">
                    <h3>Order List</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Items</th>
                                <th>Products</th>
                                <th>Total</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>001</td>
                                <td>3</td>
                                <td>Burger, Drinks, Dessert</td>
                                <td>₱100</td>
                                <td>11/18/2024</td>
                                <td><span class="status pending">Pending</span></td>
                                <td><button class="selectBtn">Select</button></td>
                            </tr>
                            <tr>
                                <td>002</td>
                                <td>1</td>
                                <td>Fries</td>
                                <td>₱50</td>
                                <td>11/18/2024</td>
                                <td><span class="status pending">Pending</span></td>
                                <td><button class="selectBtn">Select</button></td>
                            </tr>
                            <tr>
                                <td>003</td>
                                <td>1</td>
                                <td>Siomai Rice</td>
                                <td>₱50</td>
                                <td>11/18/2024</td>
                                <td><span class="status pending">Pending</span></td>
                                <td><button class="selectBtn">Select</button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Best Sellers -->
                <div class="best-sellers">
                    <h3>Best Sellers</h3>
                    <ul>
                        <li>🍱 Siomai ala Carte</li>
                        <li>🍟 Fries</li>
                        <li>🥙 Shawarma</li>
                    </ul>
                </div>
            </section>
        </main>
    </div>

    <script>
        const notifBtn = document.getElementById('notifBtn');
        const profileBtn = document.getElementById('profileBtn');
        const selectBtns = document.querySelectorAll('.selectBtn');

        const notifPopup = document.getElementById('notifPopup');
        const profilePopup = document.getElementById('profilePopup');
        const selectPopup = document.getElementById('selectPopup');

        notifBtn.onclick = () => togglePopup(notifPopup);
        profileBtn.onclick = () => togglePopup(profilePopup);
        selectBtns.forEach(btn => btn.onclick = () => togglePopup(selectPopup));

        function togglePopup(popup) {
            [notifPopup, profilePopup, selectPopup].forEach(p => {
                if (p !== popup) p.classList.remove('active');
            });
            popup.classList.toggle('active');
        }

        document.addEventListener('click', function(event) {
            if (!event.target.closest('.popup') &&
                !event.target.closest('.selectBtn') &&
                !event.target.closest('#notifBtn') &&
                !event.target.closest('#profileBtn')) {
                notifPopup.classList.remove('active');
                profilePopup.classList.remove('active');
                selectPopup.classList.remove('active');
            }
        });
    </script>
</body>
</html>
