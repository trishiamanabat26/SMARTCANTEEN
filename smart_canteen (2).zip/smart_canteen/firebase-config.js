// Firebase configuration details
const firebaseConfig = {
    apiKey: "AIzaSyBO7SMnbKbpac9gnunSTX0Rs445W7wkXvc",
    authDomain: "smartcanteen-d9071.firebaseapp.com",
    projectId: "smartcanteen-d9071",
    storageBucket: "smartcanteen-d9071.firebasestorage.app",
    messagingSenderId: "296929255961",
    appId: "1:296929255961:web:07d7ac03df687829e98088",
    measurementId: "G-7F8M4YEEQ2"
};

// Initialize Firebase
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
} else {
    firebase.app(); // Use the existing Firebase app if it's already initialized
}

// Initialize Firestore
const db = firebase.firestore();
