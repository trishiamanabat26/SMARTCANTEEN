document.addEventListener('DOMContentLoaded', function() {
    // Popup functionality
    const notifBtn = document.getElementById('notifBtn');
    const profileBtn = document.getElementById('profileBtn');
    const notifPopup = document.getElementById('notifPopup');
    const profilePopup = document.getElementById('profilePopup');

    notifBtn.onclick = () => togglePopup(notifPopup);
    profileBtn.onclick = () => togglePopup(profilePopup);

    function togglePopup(popup) {
        [notifPopup, profilePopup].forEach(p => {
            if (p !== popup) p.classList.remove('active');
        });
        popup.classList.toggle('active');
    }

    document.addEventListener('click', function(event) {
        if (!event.target.closest('.popup') &&
            !event.target.closest('#notifBtn') &&
            !event.target.closest('#profileBtn')) {
            notifPopup.classList.remove('active');
            profilePopup.classList.remove('active');
        }
    });

    // Filter tabs functionality
    const filterTabs = document.querySelectorAll('.filter-tab');
    filterTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            filterTabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // Here you would typically filter the table data
            const filterType = this.textContent.trim();
            console.log('Filtering by:', filterType);
        });
    });

    // View buttons functionality
    const viewButtons = document.querySelectorAll('.btn-view');
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const row = this.closest('tr');
            const orderId = row.cells[0].textContent;
            
            // Here you would typically show order details
            console.log('Viewing order:', orderId);
            alert(`Viewing details for Order ID: ${orderId}`);
        });
    });

    // Search functionality
    const searchInput = document.querySelector('.search-bar input');
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        const rows = document.querySelectorAll('.sales-table tbody tr');
        
        rows.forEach(row => {
            const rowText = row.textContent.toLowerCase();
            if (rowText.includes(searchTerm)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });

    // Export button functionality
    const exportBtn = document.querySelector('.btn-primary');
    if (exportBtn) {
        exportBtn.addEventListener('click', function() {
            // Here you would typically export the data
            console.log('Exporting sales data...');
            alert('Exporting sales data to CSV');
        });
    }
});

// Enhanced notification and profile functionality
notifBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    togglePopup(notifPopup);
    // Mark notifications as read when opened
    document.querySelectorAll('.notification-item.unread').forEach(item => {
        item.classList.remove('unread');
    });
    // Update badge count
    document.querySelector('.badge').style.display = 'none';
});

profileBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    togglePopup(profilePopup);
});

// Close popups when clicking outside
document.addEventListener('click', function(event) {
    if (!event.target.closest('.popup') && 
        !event.target.closest('#notifBtn') && 
        !event.target.closest('#profileBtn')) {
        notifPopup.classList.remove('active');
        profilePopup.classList.remove('active');
    }
});

// Logout button functionality
const logoutBtn = document.querySelector('.btn-logout');
if (logoutBtn) {
    logoutBtn.addEventListener('click', function() {
        if (confirm('Are you sure you want to logout?')) {
            window.location.href = 'logout.php';
        }
    });
}

// Notification click functionality
document.querySelectorAll('.notification-item').forEach(item => {
    item.addEventListener('click', function() {
        // Here you would typically navigate to the relevant order/alert
        const title = this.querySelector('.notification-title').textContent;
        alert(`Opening: ${title}`);
        notifPopup.classList.remove('active');
    });
});
