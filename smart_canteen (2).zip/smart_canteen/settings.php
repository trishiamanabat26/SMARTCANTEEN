<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Settings - Canteen Go</title>
    <link rel="stylesheet" href="dashboard.css">
    <link rel="stylesheet" href="settings.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="logo">
                <img src="food.png" alt="Logo">
                <h2>Canteen Go</h2>
            </div>
            <ul>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'home.php' ? 'active' : ''; ?>">
                    <a href="home.php"><i class="fas fa-home"></i> Home</a>
                </li>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'orders.php' ? 'active' : ''; ?>">
                    <a href="orders.php"><i class="fas fa-list"></i> Orders</a>
                </li>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'menu.php' ? 'active' : ''; ?>">
                    <a href="menu.php"><i class="fas fa-utensils"></i> Menu</a>
                </li>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'inventory.php' ? 'active' : ''; ?>">
                    <a href="inventory.php"><i class="fas fa-chart-line"></i> Sales Inventory</a>
                </li>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
                    <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
                </li>
                <li>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="topbar">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search settings...">
                </div>
                <div class="icons">
                    <i class="fas fa-bell" id="notifBtn"></i>
                    <i class="fas fa-user-circle" id="profileBtn"></i>
                </div>
            </header>

            <!-- Settings Content -->
            <section class="settings-content">
                <div class="settings-header">
                    <h2><i class="fas fa-cog"></i> Settings</h2>
                </div>
                
                <div class="settings-container">
                    <!-- Settings Navigation -->
                    <div class="settings-nav">
                        <ul>
                            <li class="active" data-tab="profile-tab">
                                <i class="fas fa-user"></i> Manage Profile
                            </li>
                            <li data-tab="accounts-tab">
                                <i class="fas fa-exchange-alt"></i> Switch Accounts
                            </li>
                            <li data-tab="add-account-tab">
                                <i class="fas fa-user-plus"></i> Add Account
                            </li>
                        </ul>
                    </div>
                    
                    <!-- Settings Panels -->
                    <div class="settings-panels">
                        <!-- Profile Management -->
                        <div class="settings-panel active" id="profile-tab">
                            <h3>Active Profile</h3>
                            <div class="profile-info">
                                <div class="info-row">
                                    <span class="info-label">Contact Number:</span>
                                    <span class="info-value">09097541389</span>
                                </div>
                                <div class="info-row">
                                    <span class="info-label">Username:</span>
                                    <span class="info-value">Staff1@gmail.com</span>
                                </div>
                            </div>
                            <button class="btn btn-primary">
                                <i class="fas fa-edit"></i> Edit Profile
                            </button>
                        </div>
                        
                        <!-- Account Switching -->
                        <div class="settings-panel" id="accounts-tab">
                            <h3>Switch Accounts</h3>
                            <div class="account-list">
                                <div class="account-item active">
                                    <i class="fas fa-check-circle"></i>
                                    <span>Station 1 (Active)</span>
                                </div>
                                <div class="account-item">
                                    <i class="fas fa-circle"></i>
                                    <span>Station 2 (Inactive)</span>
                                </div>
                            </div>
                            <button class="btn btn-secondary">
                                <i class="fas fa-sign-in-alt"></i> Switch to Selected Account
                            </button>
                        </div>
                        
                        <!-- Add Account -->
                        <div class="settings-panel" id="add-account-tab">
                            <h3>Add New Account</h3>
                            <form class="add-account-form">
                                <div class="form-group">
                                    <label for="newUsername">Username</label>
                                    <input type="text" id="newUsername" placeholder="Enter new username">
                                </div>
                                <div class="form-group">
                                    <label for="newPassword">Password</label>
                                    <input type="password" id="newPassword" placeholder="Enter password">
                                </div>
                                <div class="form-group">
                                    <label for="confirmPassword">Confirm Password</label>
                                    <input type="password" id="confirmPassword" placeholder="Confirm password">
                                </div>
                                <div class="form-group">
                                    <label for="contactNumber">Contact Number</label>
                                    <input type="tel" id="contactNumber" placeholder="09097541389">
                                </div>
                                <div class="form-actions">
                                    <button type="reset" class="btn btn-secondary">Clear</button>
                                    <button type="submit" class="btn btn-primary">Add Account</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script src="settings.js"></script>
</body>
</html>