<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Canteen Sign Up</title>
    <link rel="stylesheet" href="signup.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="image-container">
            <img src="food.png" alt="Canteen Illustration">
        </div>
        <div class="form-container">
            <h2>Create Your Account</h2>
            <?php if (isset($_GET['error'])): ?>
                <div class="error-message"><?php echo htmlspecialchars($_GET['error']); ?></div>
            <?php endif; ?>
            <?php if (isset($_GET['success'])): ?>
                <div class="success-message"><?php echo htmlspecialchars($_GET['success']); ?></div>
            <?php endif; ?>

            <form action="auth.php" method="POST">
                <input type="hidden" name="action" value="signup">

                <div class="input-container">
                    <i class="fas fa-store icon"></i>
                    <select name="station" required>
                        <option value="">Select Station</option>
                        <option value="Station 1">Station 1</option>
                        <option value="Station 2">Station 2</option>
                        <option value="Station 3">Station 3</option>
                        <option value="Station 4">Station 4</option>
                    </select>
                </div>

                <div class="input-container">
                    <i class="fas fa-user icon"></i>
                    <input type="text" name="name" placeholder="Full Name" required>
                </div>

                <div class="input-container">
                    <i class="fas fa-phone icon"></i>
                    <input type="text" name="contact" placeholder="Contact Number" required>
                </div>

                <div class="input-container">
                    <i class="fas fa-envelope icon"></i>
                    <input type="email" name="email" placeholder="Email Address" required>
                </div>

                <div class="input-container">
                    <i class="fas fa-user-circle icon"></i>
                    <input type="text" name="username" placeholder="Username" required>
                </div>

                <div class="input-container">
                    <i class="fas fa-lock icon"></i>
                    <input type="password" name="password" placeholder="Password" required>
                </div>

                <div class="input-container">
                    <i class="fas fa-lock icon"></i>
                    <input type="password" name="confirm_password" placeholder="Confirm Password" required>
                </div>

                <button type="submit" class="btn">Sign Up</button>
            </form>

            <div class="signin-link">
                Already have an account? <a href="login.php">Login here</a>
            </div>
        </div>
    </div>
</body>
</html>
