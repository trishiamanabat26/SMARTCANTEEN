<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Menu Management - Canteen Go</title>
    <link rel="stylesheet" href="dashboard.css">
    <link rel="stylesheet" href="menu.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="logo">
                <img src="food.png" alt="Logo">
                <h2>Canteen Go</h2>
            </div>
            <ul>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'home.php' ? 'active' : ''; ?>">
                    <a href="home.php"><i class="fas fa-home"></i> Home</a>
                </li>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'orders.php' ? 'active' : ''; ?>">
                    <a href="orders.php"><i class="fas fa-list"></i> Orders</a>
                </li>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'menu.php' ? 'active' : ''; ?>">
                    <a href="menu.php"><i class="fas fa-utensils"></i> Menu</a>
                </li>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'inventory.php' ? 'active' : ''; ?>">
                    <a href="inventory.php"><i class="fas fa-chart-line"></i> Inventory</a>
                </li>
                <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
                    <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
                </li>
                <li>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="topbar">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search menu items...">
                </div>
                <div class="icons">
                    <i class="fas fa-bell" id="notifBtn"></i>
                    <i class="fas fa-user-circle" id="profileBtn"></i>
                </div>
            </header>

            <!-- Popups -->
            <div class="popup" id="notifPopup">
                <div class="popup-header"><i class="fas fa-bell"></i> Notifications</div>
                <p><strong>Admin approved</strong> to add Fruitshakes Siomai on the menu.<br><small>5 minutes ago</small></p>
            </div>

            <div class="popup" id="profilePopup">
                <div class="popup-header"><i class="fas fa-user"></i> STATION 1</div>
                <p>Username: <?php echo $_SESSION['username']; ?></p>
            </div>

            <!-- Menu Management Content -->
            <section class="menu-management">
                <div class="section-header">
                    <h2>Menu Management</h2>
                    <button class="btn btn-primary" id="refreshBtn">
                        <i class="fas fa-sync-alt"></i> Refresh
                    </button>
                </div>
                
                <div class="menu-container">
                    <!-- Categories Section -->
                    <div class="menu-section categories-section">
                        <div class="section-header">
                            <h3>Manage Categories</h3>
                            <button class="btn btn-icon" id="addCategoryBtn">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                        <ul class="category-list">
                            <li class="active">
                                <span>Main Course</span>
                                <div class="item-actions">
                                    <button class="btn btn-icon btn-edit"><i class="fas fa-edit"></i></button>
                                    <button class="btn btn-icon btn-delete"><i class="fas fa-trash"></i></button>
                                </div>
                            </li>
                            <li>
                                <span>Beverages</span>
                                <div class="item-actions">
                                    <button class="btn btn-icon btn-edit"><i class="fas fa-edit"></i></button>
                                    <button class="btn btn-icon btn-delete"><i class="fas fa-trash"></i></button>
                                </div>
                            </li>
                            <li>
                                <span>Snacks</span>
                                <div class="item-actions">
                                    <button class="btn btn-icon btn-edit"><i class="fas fa-edit"></i></button>
                                    <button class="btn btn-icon btn-delete"><i class="fas fa-trash"></i></button>
                                </div>
                            </li>
                        </ul>
                    </div>
                    
                    <!-- Menu Items Section -->
                    <div class="menu-section items-section">
                        <div class="section-header">
                            <h3>Menu Items</h3>
                            <div class="filter-controls">
                                <select class="form-control">
                                    <option>All Categories</option>
                                    <option>Main Course</option>
                                    <option>Beverages</option>
                                    <option>Snacks</option>
                                </select>
                            </div>
                        </div>
                        <div class="menu-items-container">
                            <div class="menu-item active">
                                <div class="item-header">
                                    <h4>Sional Aia Carte</h4>
                                    <span class="item-price">₱30</span>
                                </div>
                                <div class="item-details">
                                    <div class="detail-row">
                                        <span class="detail-label">Item No.:</span>
                                        <span class="detail-value">00</span>
                                    </div>
                                    <div class="detail-row">
                                        <span class="detail-label">Category:</span>
                                        <span class="detail-value">Main Course</span>
                                    </div>
                                    <div class="detail-row">
                                        <span class="detail-label">Ingredients:</span>
                                        <span class="detail-value">Mango aya, Avantana, Soja con</span>
                                    </div>
                                </div>
                                <div class="item-actions">
                                    <button class="btn btn-sm btn-edit">Edit</button>
                                    <button class="btn btn-sm btn-delete">Delete</button>
                                </div>
                            </div>
                            
                            <div class="menu-item">
                                <div class="item-header">
                                    <h4>Burger Meal</h4>
                                    <span class="item-price">₱75</span>
                                </div>
                                <div class="item-details">
                                    <div class="detail-row">
                                        <span class="detail-label">Item No.:</span>
                                        <span class="detail-value">01</span>
                                    </div>
                                    <div class="detail-row">
                                        <span class="detail-label">Category:</span>
                                        <span class="detail-value">Main Course</span>
                                    </div>
                                    <div class="detail-row">
                                        <span class="detail-label">Ingredients:</span>
                                        <span class="detail-value">Beef patty, bun, lettuce, tomato, cheese</span>
                                    </div>
                                </div>
                                <div class="item-actions">
                                    <button class="btn btn-sm btn-edit">Edit</button>
                                    <button class="btn btn-sm btn-delete">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Add Item Section -->
                    <div class="menu-section add-item-section">
                        <div class="section-header">
                            <h3>Add New Item</h3>
                        </div>
                        <form class="add-item-form">
                            <div class="form-group">
                                <label for="itemName">Item Name</label>
                                <input type="text" id="itemName" placeholder="e.g., Sional Aia Carte">
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="itemNumber">Item Number</label>
                                    <input type="text" id="itemNumber" placeholder="e.g., 00">
                                </div>
                                <div class="form-group">
                                    <label for="itemPrice">Price</label>
                                    <input type="text" id="itemPrice" placeholder="e.g., 30">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="itemCategory">Category</label>
                                <select id="itemCategory">
                                    <option value="">Select Category</option>
                                    <option value="1">Main Course</option>
                                    <option value="2">Beverages</option>
                                    <option value="3">Snacks</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="itemIngredients">Ingredients</label>
                                <textarea id="itemIngredients" rows="3" placeholder="e.g., Mango aya, Avantana, Soja con"></textarea>
                            </div>
                            
                            <div class="form-actions">
                                <button type="reset" class="btn btn-secondary">Clear</button>
                                <button type="submit" class="btn btn-primary">Add Item</button>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script src="menu.js"></script>
</body>
</html>