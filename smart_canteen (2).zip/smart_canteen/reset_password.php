<?php
// reset_password.php

// Firebase Configuration
require 'vendor/autoload.php'; // Include Composer autoload

use Kreait\Firebase\Factory;
use Kreait\Firebase\Auth;

// Firebase setup
$firebase = (new Factory)->withServiceAccount('path/to/your/firebase-credentials.json');
$auth = $firebase->createAuth();

if (isset($_POST['resetPassword'])) {
    $email = $_POST['email'];

    try {
        $auth->sendPasswordResetLink($email);
        echo "Password reset link has been sent to your email.";
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | Smart Canteen</title>
</head>
<body>
    <form action="reset_password.php" method="POST">
        <div class="input-container">
            <input type="email" name="email" id="email" placeholder="Enter your email" required>
        </div>
        <button type="submit" name="resetPassword" class="btn">Send Reset Link</button>
    </form>
</body>
</html>
