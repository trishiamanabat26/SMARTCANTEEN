<?php
// send_code.php - Sends a verification code via email
session_start();
require 'db_connect.php'; // Database connection
require 'mailer.php';     // PHPMailer setup

// Enable detailed error messages for debugging (disable in production)
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']); // Sanitize input

    try {
        // Check if email exists in DB
        $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Generate random 6-digit code
            $code = rand(100000, 999999);

            // Save in session for later verification
            $_SESSION['reset_email'] = $email;
            $_SESSION['reset_code'] = $code;

            // Send the code via email
            if (send_verification_email($email, $code)) {
                // Redirect to verification page
                header("Location: verify_code.html");
                exit();
            } else {
                echo "❌ Failed to send the email. Please try again.";
            }
        } else {
            echo "⚠️ Email address not found.";
        }

        $stmt->close();
        $conn->close();

    } catch (Exception $e) {
        echo "⚠️ Error: " . $e->getMessage();
    }
}
?>
