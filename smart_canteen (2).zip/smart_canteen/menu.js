document.addEventListener('DOMContentLoaded', function() {
    // Popup functionality
    const notifBtn = document.getElementById('notifBtn');
    const profileBtn = document.getElementById('profileBtn');
    const notifPopup = document.getElementById('notifPopup');
    const profilePopup = document.getElementById('profilePopup');

    notifBtn.onclick = () => togglePopup(notifPopup);
    profileBtn.onclick = () => togglePopup(profilePopup);

    function togglePopup(popup) {
        [notifPopup, profilePopup].forEach(p => {
            if (p !== popup) p.classList.remove('active');
        });
        popup.classList.toggle('active');
    }

    document.addEventListener('click', function(event) {
        if (!event.target.closest('.popup') &&
            !event.target.closest('#notifBtn') &&
            !event.target.closest('#profileBtn')) {
            notifPopup.classList.remove('active');
            profilePopup.classList.remove('active');
        }
    });

    // Category selection
    document.querySelectorAll('.category-list li').forEach(item => {
        item.addEventListener('click', function(e) {
            // Don't trigger if clicking on action buttons
            if (e.target.closest('.item-actions')) return;
            
            document.querySelectorAll('.category-list li').forEach(li => {
                li.classList.remove('active');
            });
            this.classList.add('active');
            
            // Here you would typically filter menu items by category
            console.log('Selected category:', this.textContent.trim());
        });
    });

    // Menu item selection
    document.querySelectorAll('.menu-item').forEach(item => {
        item.addEventListener('click', function() {
            document.querySelectorAll('.menu-item').forEach(i => {
                i.classList.remove('active');
            });
            this.classList.add('active');
        });
    });

    // Form submission
    const addItemForm = document.querySelector('.add-item-form');
    if (addItemForm) {
        addItemForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const itemName = document.getElementById('itemName').value;
            const itemNumber = document.getElementById('itemNumber').value;
            const itemPrice = document.getElementById('itemPrice').value;
            const itemCategory = document.getElementById('itemCategory').value;
            const itemIngredients = document.getElementById('itemIngredients').value;
            
            // Here you would typically send this data to the server
            console.log('Adding new item:', {
                itemName,
                itemNumber,
                itemPrice,
                itemCategory,
                itemIngredients
            });
            
            // Reset form
            this.reset();
            
            // Show success message (you could implement a toast notification)
            alert('Item added successfully!');
        });
    }

    // Refresh button
    const refreshBtn = document.getElementById('refreshBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            // Here you would typically reload data from the server
            console.log('Refreshing menu data...');
            // For now, just simulate a refresh
            this.classList.add('refreshing');
            setTimeout(() => {
                this.classList.remove('refreshing');
            }, 1000);
        });
    }

    // Add category button
    const addCategoryBtn = document.getElementById('addCategoryBtn');
    if (addCategoryBtn) {
        addCategoryBtn.addEventListener('click', function() {
            const categoryName = prompt('Enter new category name:');
            if (categoryName) {
                // Here you would typically add the category to the server
                console.log('Adding new category:', categoryName);
                
                // For now, just add to the UI
                const newCategory = document.createElement('li');
                newCategory.innerHTML = `
                    <span>${categoryName}</span>
                    <div class="item-actions">
                        <button class="btn btn-icon btn-edit"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-icon btn-delete"><i class="fas fa-trash"></i></button>
                    </div>
                `;
                document.querySelector('.category-list').appendChild(newCategory);
            }
        });
    }
});