document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    const tabLinks = document.querySelectorAll('.settings-nav li');
    const tabPanels = document.querySelectorAll('.settings-panel');
    
    tabLinks.forEach(link => {
        link.addEventListener('click', function() {
            // Remove active class from all links and panels
            tabLinks.forEach(l => l.classList.remove('active'));
            tabPanels.forEach(p => p.classList.remove('active'));
            
            // Add active class to clicked link
            this.classList.add('active');
            
            // Show corresponding panel
            const tabId = this.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    // Account switching functionality
    const accountItems = document.querySelectorAll('.account-item');
    
    accountItems.forEach(item => {
        item.addEventListener('click', function() {
            if (this.classList.contains('active')) return;
            
            accountItems.forEach(i => i.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Form submission
    const addAccountForm = document.querySelector('.add-account-form');
    if (addAccountForm) {
        addAccountForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const username = document.getElementById('newUsername').value;
            const password = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const contactNumber = document.getElementById('contactNumber').value;
            
            // Basic validation
            if (password !== confirmPassword) {
                alert('Passwords do not match!');
                return;
            }
            
            // Here you would typically send the data to the server
            console.log('Adding new account:', {
                username,
                password,
                contactNumber
            });
            
            // Show success message
            alert('Account added successfully!');
            this.reset();
        });
    }
    
    // Edit profile button
    const editProfileBtn = document.querySelector('.btn-primary');
    if (editProfileBtn) {
        editProfileBtn.addEventListener('click', function() {
            // Here you would typically open an edit profile modal
            alert('Edit profile functionality would open here');
        });
    }
});